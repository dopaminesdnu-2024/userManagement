package com.example.usercenter.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.example.usercenter.model.domain.User;
import com.example.usercenter.model.domain.request.UserLoginRequest;
import com.example.usercenter.model.domain.request.UserRegisterRequest;
import com.example.usercenter.service.UserService;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.example.usercenter.constant.UserConstant.AMIN_ROLE;
import static com.example.usercenter.constant.UserConstant.USER_LOGIN_STATE;

@RestController
@RequestMapping("/user")

public class UserController {

    @Resource
    private UserService userService;


    @RequestMapping("/register")
    public Long userRegister(@RequestBody UserRegisterRequest userRegisterRequest){

        if (userRegisterRequest == null){
            return null;
        }
        // 规范写法，先声明在使用
        String userAccount = userRegisterRequest.getUserAccount();
        String userPassword = userRegisterRequest.getUserPassword();
        String checkPassword = userRegisterRequest.getCheckPassword();
        String  planetCode = userRegisterRequest.getPlanetCode();
        // 是否空？ 空不需要进行业务逻辑层
        if(StringUtils.isAnyBlank(userAccount, userPassword, checkPassword, planetCode)){
            return null;
        }


        return userService.userRegister(userAccount, userPassword, checkPassword, planetCode);


    }

    /**
     * 用户登录
     * @param userLoginRequest
     * @param request
     * @return 把用户脱敏后的信息放到session中
     */
    @PostMapping("/login")
    public User userLogin(@RequestBody UserLoginRequest userLoginRequest, HttpServletRequest request){

        if (userLoginRequest == null){
            return null;
        }
        // 规范写法，先声明在使用
        String userAccount =userLoginRequest.getUserAccount();
        String userPassword =userLoginRequest.getUserPassword();
        // 是否空？ 空不需要进行业务逻辑层
        if(StringUtils.isAnyBlank(userAccount, userPassword)){
            return null;
        }


        return userService.userLogin(userAccount,userPassword ,request);


    }


    /**
     * 用户注销
     * @param request
     * @return
     */
    @PostMapping("/logout")
    public Integer userLogout(HttpServletRequest request){
        if (request == null){
            return null;
        }
        return userService.userLogout(request);

    }

    @GetMapping("/current")
    public User getCurrentUser(HttpServletRequest request){
        // 1. get seesion
        Object userobj = request.getSession().getAttribute(USER_LOGIN_STATE);
        //  2. -> USER
        User currentUser = (User) userobj;
        // 3. 判断
        if (currentUser == null) {
            return null;
        }

        // 4. 再次查询数据库
        //todo  校验是否合法
        User user = userService.getById(currentUser.getId());
        return userService.getSafeUser(user);

         }

    /**
     *  用户搜索
     * @param username
     * @return
     */
    @GetMapping("/search")
    public List<User> serchUserList(String username, HttpServletRequest request){
        if(!isAdmin(request)){
            return new ArrayList<>();
        }

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        if(StringUtils.isNotBlank(username)){
            queryWrapper.like("username", username);
        }
        List<User> userList = userService.list(queryWrapper);

        return userList.stream().map(user -> userService.getSafeUser(user)).collect(Collectors.toList());
    }

    @PostMapping("/delete")
    public boolean deleteUser(@RequestBody long id, HttpServletRequest request){
        if(!isAdmin(request)){
            return false;
        }
        if(id < 0){
            return false;
        }

        return userService.removeById(id);
    }

    /**
     *  判断是否是管理员
     * @param request
     * @return
     */
    private boolean isAdmin(HttpServletRequest request){
        Object userObj= request.getSession().getAttribute(USER_LOGIN_STATE);
        User user = (User)userObj;
        if (user == null || user.getUserRole() != AMIN_ROLE){
            return false;
        }
        return true;
    }
}
