package com.example.usercenter.service.impl;
import java.util.Date;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.usercenter.model.domain.User;
import com.example.usercenter.service.UserService;
import com.example.usercenter.mapper.UserMapper;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.example.usercenter.constant.UserConstant.USER_LOGIN_STATE;

/**
* @author CNHan
* @description 针对表【user(用户)】的数据库操作Service实现
*
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService{

    @Resource
    private UserMapper userMapper;


    /**
     *  用户登录态的键
     */


    /**
     *  混淆加密
     */
    final private String SALT = "hcn";

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);


    /**
     *
     *
     * @param userAccount 用户账户
     * @param userPassword 用户密码
     * @param checkPassword 校验密码
     * @return 用户id
     */

    @Override
    public long userRegister(String userAccount, String userPassword, String checkPassword, String planetCode) {
        // 1. 校验非空，借助Apace Commons Lang
        if (StringUtils.isAnyBlank(userAccount, userPassword, checkPassword, planetCode)) {
            return -1;
        }
        //  检验长度
        if (userAccount.length() < 4){
            return -1;
        }


        if (userPassword.length()<8 || checkPassword.length()<8){
            return -1;
        }

        if (planetCode.length()>5){
            return -1 ;
        }

        // 2. 账户不能包含特殊字符
        // 匹配是否包含特殊字符，如果包含，返回-1
        String validPatter = "[`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Matcher matcher = Pattern.compile(validPatter).matcher(userAccount);
        if (matcher.find()){
            return -1;
        }

        // 3. 账户不能重复 QueryWrapper
        // 创建对象
        QueryWrapper<User> queryWrapper = new QueryWrapper<User>();
        // 添加等值查询
        queryWrapper.eq("userAccount", userAccount);
        //统计符合条件的数量
        long count = userMapper.selectCount(queryWrapper);
        if (count > 0){
            return -1;
        }

        // 6 组织编号不能重复
        QueryWrapper queryWrapper1 = new QueryWrapper<User>();
        queryWrapper1.eq("planetCode", planetCode);
        long count1 = userMapper.selectCount(queryWrapper1);
        if (count1 > 0){
            return -1;
        }


        // 4. 加密
//        final String SALT = "hcn";
        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + userPassword).getBytes());

        // 5 插入数据
        User user = new User();
        user.setUserAccount(userAccount);
        user.setUserPassword(encryptPassword);
        user.setPlanetCode(planetCode);


        boolean saveResult = this.save(user);
        if(!saveResult){
            return -1;
        }

        return user.getId();

    }


    @Override
    public User userLogin(String userAccount, String userPassword, HttpServletRequest request) {
        // 1. 校验非空，借助Apace Commons Lang
        if (StringUtils.isAnyBlank(userAccount, userPassword)) {
            return null;
        }
        //  检验长度
        if (userAccount.length() < 4){
            return null;
        }
        if (userPassword.length()<8 ){
            return null;
        }

        // 2. 账户不能包含特殊字符
        // 匹配是否包含特殊字符，如果包含，返回-1
        String validPatter = "[`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Matcher matcher = Pattern.compile(validPatter).matcher(userAccount);
        if (matcher.find()){
            return null;
        }

        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + userPassword).getBytes());
        //3 查询用户是否存在
        QueryWrapper queryWrapper = new QueryWrapper<User>();
        queryWrapper.eq("userAccount", userAccount);
        queryWrapper.eq("userPassword", encryptPassword);

        User user = userMapper.selectOne(queryWrapper);
        //用户不存在
        if (user == null){
            log.info("user login failed, userAccount cant match userpassword!");
            return null;
        }

        //  5. 用户脱敏
        User safedUser = getSafeUser(
                user);
        // 4 sesion记录用户的状态
        request.getSession().setAttribute(USER_LOGIN_STATE, safedUser);
        return safedUser;
    }
    @Override
    public User getSafeUser(User originalUser){
        User safeUser = new User();
        safeUser.setId(originalUser.getId());
        safeUser.setUsername(originalUser.getUsername());
        safeUser.setUserAccount(originalUser.getUserAccount());
        safeUser.setAvatarUrl(originalUser.getAvatarUrl());
        safeUser.setGender(originalUser.getGender());
        safeUser.setPhone(originalUser.getPhone());
        safeUser.setEmail(originalUser.getEmail());
        safeUser.setUserRole(originalUser.getUserRole());
        safeUser.setUserStatus(originalUser.getUserStatus());
        safeUser.setCreateTime(new Date());
        safeUser.setGroupCode(originalUser.getGroupCode());
        return safeUser;
    }


    /**
     * 用户注销
     * 移除用户的登录态
     * @return : 1 注销成功 0 注销失败
     */
    @Override
    public int userLogout(HttpServletRequest request) {
        //移除用户登录态
        request.getSession().removeAttribute(USER_LOGIN_STATE);
        return 1;
    }

}


