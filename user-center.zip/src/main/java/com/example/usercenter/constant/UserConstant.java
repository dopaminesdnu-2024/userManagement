package com.example.usercenter.constant;


/**
 *  用户常量
 */
public interface UserConstant {

    /**
     * 用户状态
     */
    final String USER_LOGIN_STATE = "userLoginState";

    /**
     *  默认权限
     *
     */

    final int DEFAULT_ROLE = 0;
    /**
     * 管理员权限
     */
    final int AMIN_ROLE = 1;
}
