package com.example.usercenter.model.domain.request;

import lombok.Data;

import java.io.Serial;
import java.io.Serializable;

/**
 * 用户前端请求体
 *
 * @author: hancongnan
 */


public class UserRegisterRequest implements Serializable {


    @Serial
    private static final long serialVersionUID = 8535601344439217331L;


    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public void setCheckPassword(String checkPassword) {
        this.checkPassword = checkPassword;
    }

    public UserRegisterRequest(String userAccount, String userPassword, String checkPassword, String planetCode) {
        this.userAccount = userAccount;
        this.userPassword = userPassword;
        this.checkPassword = checkPassword;
        this.planetCode = planetCode;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public String getCheckPassword() {
        return checkPassword;
    }

    private String userAccount;
    private String userPassword;
    private String checkPassword;

    public void setPlanetCode(String planetCode) {
        this.planetCode = planetCode;
    }

    public String getPlanetCode() {
        return planetCode;
    }

    private String planetCode;
}
