package com.example.usercenter;
import java.util.Date;

import com.example.usercenter.model.domain.User;
import com.example.usercenter.service.UserService;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


/**
 * 用户服务测试
 *
 * @author hancongnan
 */
@SpringBootTest
class UserCenterApplicationTests {


    @Resource
    UserService userService;


   @Test
    public void testAddUser(){
       User user = new User();

       user.setUsername("山师");
       user.setUserAccount("sdnu");
       user.setAvatarUrl("https://www.codefather.cn/static/bcdh_avatar.4b4d3128.webp");
       user.setGender(0);
       user.setUserPassword("xxx");
       user.setPhone("123");
       user.setEmail("456");

       user.setPlanetCode("");
       boolean result = userService.save(user);
       System.out.println(user.getId());

       Assertions.assertTrue(result);

   }

}
