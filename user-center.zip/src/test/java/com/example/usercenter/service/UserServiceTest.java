package com.example.usercenter.service;
import java.util.Date;

import com.example.usercenter.model.domain.User;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;




@SpringBootTest
class UserServiceTest {

    @Resource
    private UserService userService;

    @Test
    public void testAddUser(){
        User user = new User();
        user.setUsername("韩");
        user.setUserAccount("hancongnan");
        user.setAvatarUrl("https://www.codefather.cn/static/bcdh_avatar.4b4d3128.webp");
        user.setGender(0);
        user.setUserPassword("123");
        user.setPhone("123");
        user.setEmail("123@qq.com");
        user.setPlanetCode("1");


        boolean result = userService.save(user);
        assertTrue(result);
    }

    @Test
    void userRegister() {
//        String userAccount = "hancongnan";
//        String userPassword = "";
//        String checkPassword = "123456";
//
//        // 非空测试
//        long result = userService.userRegister(userAccount, userPassword, checkPassword);
//        Assertions.assertEquals(-1, result);
//        //不小于4位 测试
//        userAccount = "han";
//        result = userService.userRegister(userAccount, userPassword, checkPassword);
//        Assertions.assertEquals(-1, result);
//
//        //密码不小于8
//        userAccount = "hancongnan";
//        userPassword = "123456";
//        result = userService.userRegister(userAccount, userPassword, checkPassword);
//        Assertions.assertEquals(-1, result);
//
//        //账户不包含特殊字符
//        userAccount = "han ongnan";
//        userPassword = "12345678";
//        result = userService.userRegister(userAccount, userPassword, checkPassword);
//        Assertions.assertEquals(-1, result);
//        // 密码和校验码不相同
//        userAccount = "hancongnan";
//        userPassword = "12345678";
//        checkPassword = "1234567809";
//        result = userService.userRegister(userAccount, userPassword, checkPassword);
//        Assertions.assertEquals(-1, result);
        // 密码和校验码相同
//        userAccount = "hancongnanttt";
//        userPassword = "12345678";
//        checkPassword = "12345678";
//        result = userService.userRegister(userAccount, userPassword, checkPassword);
//        Assertions.assertEquals(-1, result);

          String userAccount = "admin12345";
          String userPassword = "123456789";
          String checkPassword = "123456789";
          String planetCode = "9528";
          long result = userService.userRegister(userAccount, userPassword, checkPassword, planetCode);
          Assertions.assertTrue(result>0);
    }
}